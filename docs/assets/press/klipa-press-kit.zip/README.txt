klipa - Press Kit
=================

Contents
--------
BOILERPLATE.txt                  Ready-to-use paragraph about klipa
FACT-SHEET.txt                   Product facts in a compact table
klipa-app-icon.png               App icon (512x512)
klipa-favicon.png                Small logo mark (256x256)
klipa-01-clipboard-history.png   Clipboard history dropdown
klipa-02-keep-awake.png          Keep-awake sessions
klipa-03-menu-bar-display.png    Menu bar display options
klipa-04-dropdown-size.png       Configurable dropdown size

Usage
-----
Everything in this kit is free to use in coverage of klipa, provided
klipa is credited and screenshots are not altered in a way that
misrepresents the product. All screenshots are 2560 x 1600.

Press contact
-------------
Petros Dhespollari
info@peterdsp.dev
https://peterdsp.dev
